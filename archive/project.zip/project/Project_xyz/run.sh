#!/bin/bash
project_name=Project_xyz
root_path=/home/qiime/Desktop/Shared_Folder/factory/project/
data=("validate_mapping_file#validate_mapping_file.py -m ../input/Project_stoica_open_mapping.txt -o output/ " "convert_fastaqual_fastq#convert_fastaqual_fastq.py -f ../input/inseqs.fastq -q ../input/080714JS530Filluminaull.qual -o output/ ")
log_file="$project_name.log.txt"
project_path="$root_path$project_name/"
cmd_file="$project_name.commands.txt"
author="Piyush Tripathi(thepiyush13@gmail.com)"
error=1
run_safe() {
   CMD="$1"
   echo  "Executing command# $CMD"
   echo "COMMAND# $CMD DATE# `date`" >> $project_path$cmd_file
   echo "------------ Begin Command# $CMD DATE# `date`" >> $project_path$log_file
   $CMD &>> $project_path$log_file
   error=$?
   until [ ${error} -eq 0 ]; do
    read -p "Error Occurred for  command# $CMD , Enter new command :  " CMD
   echo "Rerun Command# $CMD DATE# `date`" >> $project_path$log_file
     $CMD &>> $project_path$log_file
     error=$?    
    done
  echo  "Command Success !"
}
function project_header(){
  temp="$1"
  out_file="$project_path$temp"
  echo "@--------------------Project Summary--------------------------------@" >> $out_file
  echo "Project# $project_name" >> $out_file
  echo "Project Path# $project_path" >> $out_file
  echo "Project Commands# $project_path$cmd_file" >> $out_file
  echo "Project log# $project_path$log_file" >> $out_file
  echo "Created By# $author" >> $out_file
  echo "@-------------------------------------------------------------------@" >> $out_file
}
#init for script
touch "$project_path$cmd_file" "$project_path$log_file"
project_header "$cmd_file"
project_header "$log_file"
for val in "${data[@]}";
do
  #split the array value for step and command
  IFS="#" read -a line <<< "$val" 
  step=${line[0]}
  cmd=${line[1]}
  cd $project_path &&  mkdir -p "$step/output" &&  cd $step 
  run_safe "$cmd"
done
